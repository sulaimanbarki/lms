<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss/dist/tailwind.min.css">
</head>
<body>
    <a href="/questions/create" class="text-blue-500 hover:text-blue-700">
        <i class="fas fa-plus-circle"></i>
        Add Question
    </a>
    <a href="/dashboard" class="text-blue-500 hover:text-blue-700">
        <i class="fas fa-plus-circle"></i>
        Dashboard
    </a>
    <div class="flex flex-wrap -m-2">
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-full md:w-1/2 p-2">
                <div class="bg-white overflow-hidden shadow-lg">
                    <div class="p-4">
                        <h3 class="font-semibold text-xl text-gray-800 leading-tight">
                            <?php echo e($question->question); ?>

                        </h3>
                        <p class="text-gray-700 text-base">
                            <?php echo e($question->answer); ?>

                        </p>
                        <p class="text-gray-700 text-base">
                            <?php echo e($question->subject->name); ?>

                        </p>
                        <p class="text-gray-700 text-base">
                            <?php echo e($question->subject->department->name); ?>

                        </p>
                        <a href="/questions/<?php echo e($question->id); ?>/edit" class="text-blue-500 hover:text-blue-700">
                            <i class="fas fa-edit"></i>
                            Edit
                        </a>
                        <form action="/questions/<?php echo e($question->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 hover:text-red-700">
                                <i class="fas fa-trash-alt"></i>
                                Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\PK\Dropbox\PC (4)\Documents\Basit web\basit website\mysite\resources\views/questions/index.blade.php ENDPATH**/ ?>