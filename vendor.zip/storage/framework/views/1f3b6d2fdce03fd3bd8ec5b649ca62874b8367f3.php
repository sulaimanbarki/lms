<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(route('subjects.create')); ?>">Add Subject</a>
    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Department</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subject->id); ?></td>
                    <td><?php echo e($subject->name); ?></td>
                    <td><?php echo e($subject->department->name); ?></td>
                    
                    <td>
                        <a href="/subjects/<?php echo e($subject->id); ?>/edit" class="btn btn-primary">Edit</a>
                        <form action="/subjects/<?php echo e($subject->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</body>
</html><?php /**PATH C:\Users\Alpha\Dropbox\PC (4)\Documents\Basit web\basit website\mysite\resources\views/subject/index.blade.php ENDPATH**/ ?>