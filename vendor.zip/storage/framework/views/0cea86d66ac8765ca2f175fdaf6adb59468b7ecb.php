

<img src="<?php echo e(asset('images/logo.png')); ?>" style="width:200px; margin-top:-75px; box-size:border-box;
 padding:10px;filter: drop-shadow(0px 5px 5px rgb(162, 162, 162));"   alt="">
<?php /**PATH C:\Users\Alpha\Dropbox\Basit\mysite\resources\views/components/application-logo.blade.php ENDPATH**/ ?>