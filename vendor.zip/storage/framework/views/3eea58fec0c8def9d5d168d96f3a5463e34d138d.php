<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- End Header-->



<!-- =================================== main  =======================================  -->

<body style="background-color: #fdf4e2;">

    <div class="container-fluid" id="main">
        <div class="row">
            <!-- Background image -->
            <div class="img-fluid bg-image topimage ">



                <!--  -->
                <?php echo $__env->make('frontend.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>


    

    
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="search-form">
                    <form action="<?php echo e(route('courses')); ?>" id="" method="get" >
                        <div class="form-group">
                            <input type="text" class="form-control" style=" font-size:1.5rem;" name="search" placeholder="Search">
                        </div>
                        <div class="form-group mt-3" style="text-align: right;">
                            <button id="searchform" type="submit" class="btn btn-primary float-right">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="container my-5">
        <div class="row">
            <div class="col-md-12">
                <div class="video-list">
                    <div class="row g-3 courses " id="blog-post">
                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 courses_video">
                            <div class="video-item">
                                <div class="video-info">



                                    
                                    <?php if($video->is_playlist): ?>


                                    <div class="card" style="width: 25rem;">
                                        
                                        <img src="<?php echo e(asset('uploads/thumbnail/'.$video->thumbnail_url)); ?>"
                                            class=" img-fluid card-img-top" alt="...">
                                        <div class="card-body">
                                            <h5 class="card-title">
                                                <a href="/coursess/<?php echo e($video->id); ?>">
                                                    <h5><?php echo e($video->title); ?></h5>
                                                </a>
                                            </h5>
                                            <a href="/coursess/<?php echo e($video->id); ?>" class="btn btn-primary">Watch Course</a>
                                        </div>
                                    </div>

                                    <?php else: ?>

                                    
                                    <div class="card" style="width: 25rem;">
                                        
                                        <img src="<?php echo e(asset('uploads/thumbnail/'.$video->thumbnail_url)); ?>"
                                            class="img-fluid card-img-top" alt="...">
                                        
                                        <div class="card-body">
                                            <h5 class="card-title">
                                                <a href="/course/<?php echo e($video->id); ?>">
                                                    <h5><?php echo e($video->title); ?></h5>
                                                </a>
                                            </h5>
                                            <a href="/course/<?php echo e($video->id); ?>" class="btn btn-primary">Watch Video</a>
                                        </div>
                                    </div>

                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <p class="card-text"><?php echo e($videos->links()); ?></p>


                    </div>
                </div>
            </div>
        </div>
    </div>
    
    




    <!-- =================================== Footer ===================================-->
    <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =================================== Footer ===================================-->


    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



    <script>
        $("#searchform").click(function () {
                            $.ajax({
                                url: "<?php echo e(route('coursesSearch')); ?>",
                                type: "GET",
                                data: $("#searchformm").serialize(),
                                success: function (data) {
                                    // show blog post return in data
                                    $("#blog-post").empty();
                                    // display all videos's title and links returned in data
                                    $.each(data, function (i, item) {
                                        $("#blog-post").append(
                                            '<div class="col-md-4">' +
                                                '<div class="video-item">' +
                                                    '<div class="video-info">' +
                                                        (item.is_playlist ? '<a href="/courses/' + item.id + '"><h5>' + item.title + '</h5></a>' : '<a href="/course/' + item.id + '"><h5>' + item.title + '</h5></a>') +
                                                        // limit the number of item.description = 80 char
                                                        '<p>' + item.description.substring(0, 80) + '...</p>' +
                                                    '</div>' +
                                                '</div>' +
                                            '</div>'
                                        );
                                    });
                                }
                            });
                        });
    </script>

</body>

</html>
<?php /**PATH C:\Users\Alpha\Dropbox\Basit\mysite\resources\views/frontend/pages/courses.blade.php ENDPATH**/ ?>