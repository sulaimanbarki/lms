<?php echo e($slot); ?>

<?php /**PATH C:\Users\PK\Dropbox\Basit\mysite\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>