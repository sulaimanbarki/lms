<?php $__env->startSection('content'); ?>

<!-- content section -->
<div class="container my-3">

    <!-- create subject form -->
    <form action="<?php echo e(route('subjects.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Enter name">
        </div>
        <div class="form-group mt-2">
            <label for="department_id">Department</label>
            <select name="department_id" id="department_id" class="form-control">
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>


        <div style="text-align: end;">
            <button type="submit" class="btn btn-primary mt-2" >Submit</button>
        </div>

        </div>

    </form>

    </div>
<!-- End content section -->

<!-- End create subject form -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Dashboard.pages.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alpha\Dropbox\Basit\mysite\resources\views/Admin/Dashboard/pages/subject/create.blade.php ENDPATH**/ ?>