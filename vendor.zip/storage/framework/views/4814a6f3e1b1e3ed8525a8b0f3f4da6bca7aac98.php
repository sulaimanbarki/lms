<?php $__env->startSection('content'); ?>
        <!-- create blog link -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Create Blog</a>
                            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">Dashboard</a>
                        </div>
                    </div>
                </div>
            </div>
            
            
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table mr-1"></i>
                    Blogs
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($blog->id); ?></td>
                                        <td><?php echo e($blog->title); ?></td>
                                        <td>
                                            <a href="/blogs/<?php echo e($blog->id); ?>/edit" class="btn btn-primary ">Edit</a>
                                            <form action="/blogs/<?php echo e($blog->id); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" onclick="return confirm('Are you shure to delete this record?')" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            


        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Dashboard.pages.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PK\Dropbox\Basit\mysite\resources\views/Admin/Dashboard/pages/blogs/index.blade.php ENDPATH**/ ?>