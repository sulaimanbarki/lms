
<div class="container">
    
    <a href="/departments/create" class="btn btn-primary">
        <i class="fas fa-plus-circle"></i>
        Add Department
    </a>
    <hr>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Department List</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($department->id); ?></td>
                                <td><?php echo e($department->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('departments.edit', $department->id)); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(route('departments.show', $department->id)); ?>" class="btn btn-primary">View</a>
                                    <form action="<?php echo e(route('departments.destroy', $department->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row --><?php /**PATH C:\Users\PK\Dropbox\PC (4)\Documents\Basit web\basit website\1 dashboard\Basit web\basit website\mysite\resources\views/Admin/Dashboard/pages/department/index.blade.php ENDPATH**/ ?>