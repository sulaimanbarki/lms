<?php $__env->startSection('content'); ?>


                        <h1 class="mt-4">Dashboard</h1>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">Total Questions</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <?php
                                            $total_questions = DB::table('question_answers')->count();
                                        ?>
                                        <h3><a class="small text-white stretched-link" href="#"><?php echo e($total_questions); ?></a></h3>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">Total Blogs</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <?php
                                            $total_blogs = DB::table('blogs')->count();
                                        ?>
                                        <h3><a class="small text-white stretched-link" href="#"><?php echo e($total_blogs); ?></a></h3>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">Total Videos</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <?php
                                            $total_videos = DB::table('videos')->count();
                                        ?>
                                        <h3><a class="small text-white stretched-link" href="#"><?php echo e($total_videos); ?></a></h3>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body">Users</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <?php
                                            $total_users = DB::table('users')->count();
                                        ?>
                                        <h3><a class="small text-white stretched-link" href="#"><?php echo e($total_users); ?></a></h3>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Dashboard.pages.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PK\Dropbox\Basit\mysite\resources\views/Admin/Dashboard/pages/index.blade.php ENDPATH**/ ?>