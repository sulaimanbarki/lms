<?php $__env->startSection('content'); ?>

<!-- content section -->
<div class="container my-3">

    <!-- Question Answers section -->
    <a href="/questions/create" class="btn btn-primary text-blue-500 hover:text-blue-700">
        <i class="fas fa-plus-circle"></i>
        Add Question
    </a>
    <a href="/dashboard" class="btn btn-primary text-blue-500 hover:text-blue-700">
        Dashboard
    </a>
    <div class="flex flex-wrap -m-2">
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-full md:w-1/2 p-2">
                <div class="bg-white overflow-hidden shadow-lg">
                    <div class="p-4">
                        <h3 class="font-semibold text-xl text-gray-800 leading-tight">
                            <?php echo e($question->question); ?>

                        </h3>
                        <p class="text-gray-700 text-base">
                            
                            <?php echo e(substr($question->answer, 0, 200)); ?>

                        </p>
                        <p class="text-gray-700 text-base">
                            <span class="text-primary">Subject</span> <?php echo e($question->subject->name); ?>

                        </p>
                        <p class="text-gray-700 text-base">
                            <span class="text-primary">Department</span> <?php echo e($question->subject->department->name); ?>

                        </p>
                        <a href="/questions/<?php echo e($question->id); ?>/edit" class="text-blue-500 hover:text-blue-700">
                            <i class="fas fa-edit"></i>
                            Edit
                        </a>
                        <form action="/questions/<?php echo e($question->id); ?>" method="POST" onsubmit="return confirm('Are you shure to delete this record?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 hover:text-red-700">
                                <i class="fas fa-trash-alt"></i>
                                Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- Question Answers section -->

<!-- End content section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Dashboard.pages.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alpha\Dropbox\Basit\mysite\resources\views/Admin/Dashboard/pages/questionAnswer/index.blade.php ENDPATH**/ ?>