<?php $__env->startSection('content'); ?>

<!-- content section -->
<div class="container my-3">

    <a href="<?php echo e(route('subjects.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus-circle"></i>
        Add Subject
    </a>

    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">Dashboard</a>
    
    <?php if(session('delete_error')): ?>
        <div class="alert alert-danger my-3">
            <?php echo e(session('delete_error')); ?>

        </div>
    <?php endif; ?>
    <table id="example1" class="table table-bordered table-striped my-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Department</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subject->id); ?></td>
                    <td><?php echo e($subject->name); ?></td>
                    <td><?php echo e($subject->department->name); ?></td>
                    
                    <td>
                        <a href="/subjects/<?php echo e($subject->id); ?>/edit" class="btn btn-primary ">Edit</a>
                        <form action="/subjects/<?php echo e($subject->id); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this record?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<!-- End content section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Dashboard.pages.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alpha\Dropbox\Basit\mysite\resources\views/Admin/Dashboard/pages/subject/index.blade.php ENDPATH**/ ?>