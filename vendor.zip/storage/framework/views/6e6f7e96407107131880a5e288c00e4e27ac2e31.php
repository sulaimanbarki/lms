<?php $__env->startSection('content'); ?>

<!-- content section -->
<div class="container my-3">
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Contacts</h3>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Message</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($contact->name); ?></td>
                                <td><?php echo e($contact->email); ?></td>
                                <td><?php echo e($contact->subject); ?></td>
                                <td><?php echo e($contact->message); ?></td>
                                <td>
                                    <a href="<?php echo e(route('contacts.show', $contact->id)); ?>" class="btn btn-primary">Show</a>
                                    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo e($contacts->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End content section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Dashboard.pages.masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alpha\Dropbox\Basit\mysite\resources\views/admin/dashboard/pages/contact/index.blade.php ENDPATH**/ ?>