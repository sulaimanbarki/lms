<nav class="navbar navbar-expand-lg navbar-dark ">
    <div class="container-fluid">
        <!-- <a class="navbar-brand" href="#">Navbar</a> -->

        <img src="images/logo.png" alt="Avatar Logo" class="mt-3" style="width:160px;">

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto ">
                <li class="nav-item">
                    <a class="nav-link" style="color: #FFF;" aria-current="page" href="<?php echo e(route('index')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: #FFF;"
                        href="<?php echo e(route('engineering')); ?>">Engineering</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: #FFF;" href="<?php echo e(route('freelancing')); ?>">Freelancing</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: #FFF;" href="<?php echo e(route('courses')); ?>" tabindex="-1"
                        aria-disabled="true">Courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color: #FFF;" href="<?php echo e(route('engineering')); ?>" tabindex="-1"
                        aria-disabled="true">Contact us</a>
                </li>
            </ul>

            <!-- extra div -->
            <div class="col-md-1"></div>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\Alpha\Dropbox\Basit\mysite\resources\views/frontend/pages/navbar.blade.php ENDPATH**/ ?>