<?php

interface com_wiris_plugin_asyncapi_StringCallback {
	function error($msg);
	function returnString($str);
}
